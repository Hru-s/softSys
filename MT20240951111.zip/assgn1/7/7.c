/*
===========================================================================================================================
Name : 7.c
Author : Hrushikesh Nakka
Description : Write a program to copy file1 into file2 ($cp file1 file2).
Date: 27th Aug, 2024.
===========================================================================================================================
*/
#include <stdlib.h>
int main() {
    system("cp original.txt dup.txt");
    return 0;
}
