#include<stdio.h>

int main(int argc, char *argv[1]){
printf("hi  %s\n",argv[1]);
return 0;}
